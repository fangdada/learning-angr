import angr
import claripy

def is_alnum(state, c):
    is_num = state.solver.And(c >= ord("0"), c <= ord("9"))
    is_alpha_lower = state.solver.And(c >= ord("a"), c <= ord("z"))
    is_alpha_upper = state.solver.And(c >= ord("A"), c <= ord("Z"))
    is_zero = (c == ord('\x00'))
    isalphanum = state.solver.Or(
        is_num, is_alpha_lower, is_alpha_upper, is_zero)
    return isalphanum

p = angr.Project("./bomb", auto_load_libs=False)

p.hook(0x0000000000401338, angr.SIM_PROCEDURES['libc']['strcmp']())
p.hook(0x000000000040131B, angr.SIM_PROCEDURES['libc']['strlen']())

p.analyses.CFG()

start = p.kb.obj.get_symbol('phase_5').rebased_addr
avoid = p.kb.obj.get_symbol('explode_bomb').rebased_addr
find = p.kb.functions.get('phase_5').ret_sites[0].addr

state = p.factory.blank_state(addr=start)
state.regs.rdi = state.regs.rsp - 0x1000
string_addr = state.regs.rdi
sm = p.factory.simulation_manager(state)
sm.explore(find=find, avoid=avoid)
found = sm.found[0]

mem = found.memory.load(string_addr, 32)
for i in range(32):
    found.add_constraints(is_alnum(found, mem.get_byte(i)))
print(found.solver.eval(mem, cast_to=bytes).split(b'\x00')[0].decode())
