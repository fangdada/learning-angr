import angr
import claripy

start=0x40102E
end=0x40105D
explode_bomb=0x40143a

p=angr.Project('./bomb')
initial_state=p.factory.blank_state(addr=start)

sm=p.factory.simulation_manager(initial_state)

sm.explore(find=end,avoid=explode_bomb)

found=sm.found[0]

found.stack_pop()
flag=found.stack_pop()

data=found.solver.eval(flag,cast_to=int)

input1=data&0xFFFFFFFF
input2=(data>>32)&0xFFFFFFFF

print('input1:{}\ninput2:{}'.format(input1,input2))
