import angr
import claripy
import time

class read_6_ints(angr.SimProcedure):
    answer_ints = []  # class variable
    int_addrs = []

    def run(self, s1_addr, int_addr):
        print(int_addr)
        self.int_addrs.append(int_addr)
        for i in range(6):
            bvs = self.state.solver.BVS("phase6_int_%d" % i, 32)
            self.answer_ints.append(bvs)
            self.state.mem[int_addr].int.array(6)[i] = bvs

        return 6

start = 0x4010f4
read_num = 0x40145c

#split the function to two parts to avoid path explosion
find1 = 0x401188
find2 = 0x4011f7
avoid = 0x40143A

before=time.time()
p = angr.Project("./bomb", auto_load_libs=False)
p.hook(read_num, read_6_ints())
state = p.factory.blank_state(addr=start, remove_options={angr.options.LAZY_SOLVES})
sm = p.factory.simulation_manager(state)

'''
# enumerate all possible paths in the first part
while len(sm.active) > 0:
    sm.explore(find=find1, avoid=avoid)

# dive further to part2
found_list = sm.found
for found in found_list:
    sm = p.factory.simulation_manager(found)
    sm.explore(find=find2, avoid=avoid)
    if len(sm.found) > 0:
        found = sm.found[0]
        break
'''
sm.explore(find=find2,avoid=avoid)
found=sm.found[0]
after=time.time()

answer = [found.solver.eval(x) for x in read_6_ints.answer_ints]
print(' '.join(map(str, answer)))
print("cost:"+str(after-before))
# 优化后cost:89.82110810279846
# 优化前cost:170.6358540058136
