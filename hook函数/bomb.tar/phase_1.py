import angr
import claripy

start=0x400EE0
end=0x400EF7
explode_bomb=0x40143A
strings_not_equal=0x401338
strings_addr=0x603780

p=angr.Project('./bomb')
p.hook(strings_not_equal,angr.SIM_PROCEDURES['libc']['strcmp']())

initial_state=p.factory.blank_state(addr=start)

flag1=claripy.BVS("flag1",128*8)
initial_state.memory.store(strings_addr,flag1)
initial_state.regs.rdi=strings_addr

sim=p.factory.simulation_manager(initial_state)
sim.explore(find=end,avoid=explode_bomb)

print(sim.found[0].solver.eval(flag1,cast_to=bytes).split(b'\x00')[0])
