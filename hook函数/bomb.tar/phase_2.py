import angr
import claripy

start=0x400f0a
explode_bomb=0x40143a
end=0x400f3c

p=angr.Project('./bomb',auto_load_libs=False)
initial_state=p.factory.blank_state(addr=0x400f0a)

for i in range(6):
    initial_state.stack_push(initial_state.solver.BVS("int{}".format(i),32))

sim=p.factory.simulation_manager(initial_state)
sim.explore(find=end,avoid=explode_bomb)

found=sim.found[0]
flag2=[]

for i in range(3):
    cur_int=found.solver.eval(found.stack_pop())

    flag2.append(str(cur_int&0xFFFFFFFF))
    flag2.append(str(cur_int>>32&0xFFFFFFFF))


print(' '.join(flag2))
