import angr
import claripy

start=0x400f6a
end=0x400fc9
explode_bomb=0x40143a

p=angr.Project('./bomb')

initial_state=p.factory.blank_state(addr=start)

sm=p.factory.simulation_manager(initial_state)
sm.explore(find=end,avoid=explode_bomb)

flag={}

for i in sm.found:
    i.stack_pop()
    data=i.solver.eval(i.stack_pop(),cast_to=int)

    cmd=data&0xFFFFFFFF
    num=(data>>32)&0xFFFFFFFF
    flag[cmd]=num

for i in sm.active:
    if i.addr!=end:
        continue
    i.stack_pop()
    data=i.solver.eval(i.stack_pop(),cast_to=int)

    cmd=data&0xFFFFFFFF
    num=(data>>32)&0xFFFFFFFF
    flag[cmd]=num

for i in set(flag):
    print("{}:{} ".format(i,flag[i]))
